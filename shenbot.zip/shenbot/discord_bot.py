import discord
from discord.ext import commands, tasks
import json
import os
import random
from datetime import timedelta, datetime
import aiohttp
from aiohttp import web
from pymongo import MongoClient, DESCENDING
import threading
from flask import Flask
import urllib.parse
import asyncio


mongo_uri = "mongodb://localhost:27017/myDatabase"
client = MongoClient(mongo_uri)
try:
    db = client.myDatabase 
    print("Connected to MongoDB!")
finally:
    client.close()
app = Flask(__name__)
@app.route('/')
def home():
    return "Hello, Replit!"
TOKEN = os.getenv('DISCORD_TOKEN')
if not TOKEN:
    print("ERROR: DISCORD_TOKEN is not set")
    exit(1)
intents = discord.Intents.default()
intents.message_content = True
intents.members = True

bot = commands.Bot(command_prefix='!', intents=intents, help_command=None)
WELCOME_CHANNEL_ID = 1280071795986403393
LOG_CHANNEL_ID = 1392463222103212144
COMMANDS_CHANNEL_ID = 1290295233300402227
MODERATOR_ROLE_NAME = '🛡 Модератор'
REQUIRED_ROLE_NAME = '✭'
TWITCH_CHANNEL = 'shenfrush'
TWITCH_CLIENT_ID = os.getenv('TWITCH_CLIENT_ID')
TWITCH_CLIENT_SECRET = os.getenv('TWITCH_CLIENT_SECRET')
TWITCH_OAUTH_TOKEN = os.getenv('TWITCH_OAUTH_TOKEN')
NOTIFY_CHANNEL_ID = 1301387969994952745 
TwitchAPIURL = 'https://api.twitch.tv/helix/streams?user_login=ShenFRusH'
is_streaming = False
mongo_uri = os.getenv('MONGO_URI')
mongo_client = MongoClient(mongo_uri, tls=True, tlsAllowInvalidCertificates=True)
db = mongo_client["shenbot"]
users_collection = db["users"]



twitch_access_token = None
is_streaming = False

async def get_twitch_token():
    global twitch_access_token
    url = "https://id.twitch.tv/oauth2/token"
    params = {
        "client_id": TWITCH_CLIENT_ID,
        "client_secret": TWITCH_CLIENT_SECRET,
        "grant_type": "client_credentials"
    }
    async with aiohttp.ClientSession() as session:
        async with session.post(url, params=params) as resp:
            data = await resp.json()
            twitch_access_token = data.get("access_token")
            if twitch_access_token:
                print("[TWITCH] Получен токен")
            else:
                print(f"[TWITCH] Ошибка получения токена: {data}")

async def check_stream_status():
    global is_streaming, twitch_access_token
    if not twitch_access_token:
        await get_twitch_token()

    url = f"https://api.twitch.tv/helix/streams?user_login={TWITCH_CHANNEL}"
    headers = {
        'Client-ID': TWITCH_CLIENT_ID,
        'Authorization': f'Bearer {twitch_access_token}'
    }

    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as response:
            data = await response.json()
            print("[TWITCH] Ответ API:", data)
            if 'data' in data and data['data']:
                if not is_streaming:
                    is_streaming = True
                    stream_info = data['data'][0]
                    viewer_count = stream_info.get('viewer_count', 0)
                    title = stream_info.get('title', 'Без названия')
                    game_name = "Не указана"

                    game_id = stream_info.get("game_id")
                    if game_id:
                        async with session.get(f"https://api.twitch.tv/helix/games?id={game_id}", headers=headers) as game_resp:
                            game_data = await game_resp.json()
                            if game_data.get("data"):
                                game_name = game_data["data"][0]["name"]

                    await send_stream_notification(viewer_count, title, game_name)
            else:
                if is_streaming:
                    print("[TWITCH] Стрим закончился")
                is_streaming = False

async def send_stream_notification(viewer_count, title, game_name):
    channel = bot.get_channel(NOTIFY_CHANNEL_ID)
    stream_url = f"https://www.twitch.tv/{TWITCH_CHANNEL}"

    embed = discord.Embed(
        title="🎮 Стрим начался!",
        description=f"**Игра:** {game_name}\n**Зрителей:** {viewer_count}\n**Название:** {title}",
        color=discord.Color.blue()
    )
    embed.add_field(name="💥 Ссылка на стрим", value=f"[Перейти]({stream_url})", inline=False)
    embed.set_footer(text="by BOSasha • Shenята | TWITCH")

    if channel:
        await channel.send("@everyon Шен запустил стрим!", embed=embed)
        print("[TWITCH] Уведомление отправлено")
    else:
        print("[TWITCH] Канал для уведомлений не найден")

@tasks.loop(minutes=1)
async def auto_notify_stream():
    print("[TASK] Проверяю статус стрима...")
    await check_stream_status()

@bot.event
async def on_ready():
    print(f'Бот {bot.user} подключён к Discord!')
    await get_twitch_token()
    auto_notify_stream.start()

    activity = discord.Activity(
        type=discord.ActivityType.watching,
        name="стрим ShenFRusH"
    )
    await bot.change_presence(activity=activity)

def get_user_data(user_id):
    user = users_collection.find_one({"_id": str(user_id)})
    if not user:
        user = {"_id": str(user_id), "xp": 0, "level": 0, "last_message_day": str(datetime.today().date())}
        users_collection.insert_one(user)
    return user
def update_user_data(user_id, data):
    result = users_collection.update_one({"_id": str(user_id)}, {"$set": data}, upsert=True)
    print(f"Обновлено документов: {result.modified_count}, апсертов: {result.upserted_id}")
LEVEL_ROLES = {
    10: '🟥 Паралелепипед',
    15: '👾 Полупок',
    20: '✨ VIP',
}
GIF_WELCOME_URL = 'https://media.discordapp.net/attachments/685815150376255502/1282276742664425504/TIIINzVMap8.gif'
GIF_GOODBYE_URL = 'https://media.discordapp.net/attachments/937113595219693588/1333162715853623406/ezgif-2-bb540f2ee7.gif'

with open("fairytales.json", "r", encoding="utf-8") as f:
    fairy_tales = json.load(f)

def has_moderator_role():
    async def predicate(ctx):
        role = discord.utils.get(ctx.author.roles, name=MODERATOR_ROLE_NAME)
        if role is None:
            await ctx.send("🚫 У тебя нет прав модератора для этой команды!")
            return False
        return True
    return commands.check(predicate)
def has_required_role():
    async def predicate(ctx):
        role = discord.utils.get(ctx.author.roles, name=REQUIRED_ROLE_NAME)
        if role is None:
            await ctx.send("🚫 У тебя нет прав на выполнение этой команды!")
            return False
        return True
    return commands.check(predicate)
def xp_for_next_level(level):
    return (level * 100) + 200


@bot.event
async def on_message(message):
    if message.author.bot:
        return
    if message.content.startswith(bot.command_prefix):
        await bot.process_commands(message)
        return

    user_id = str(message.author.id)
    user_data = get_user_data(user_id)
    current_day = str(datetime.today().date())

    if user_data.get('last_message_day') != current_day:
        xp_gain = random.randint(10, 15)
        user_data['last_message_day'] = current_day
    else:
        xp_gain = random.randint(1, 5)

    user_data.setdefault("level", 0)
    user_data.setdefault("xp", 0)  
    user_data.setdefault("total_xp", 0)

    user_data["xp"] += xp_gain
    user_data["total_xp"] += xp_gain
    update_user_data(user_id, user_data)

    current_level = user_data["level"]
    xp_to_next = xp_for_next_level(current_level)

    if user_data["xp"] >= xp_to_next:
        old_level = current_level
        user_data["level"] += 1
        user_data["xp"] -= xp_to_next 
        update_user_data(user_id, user_data)

        guild = message.guild
        member = message.author

        for lvl, role_name in LEVEL_ROLES.items():
            role = discord.utils.get(guild.roles, name=role_name)
            if role and role in member.roles and lvl > user_data["level"]:
                await member.remove_roles(role)

        give_role_name = None
        for lvl, role_name in sorted(LEVEL_ROLES.items()):
            if user_data["level"] >= lvl:
                give_role_name = role_name
            else:
                break

        if give_role_name:
            role = discord.utils.get(guild.roles, name=give_role_name)
            if role and role not in member.roles:
                await member.add_roles(role)

        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel:
            embed = discord.Embed(
                title="🔼 Повышение уровня",
                description=(
                    f"Пользователь: {member.mention}\n"
                    f"Старый уровень: {old_level}\n"
                    f"Новый уровень: {user_data['level']}\n"
                    f"Текущий XP: {user_data['xp']}/{xp_for_next_level(user_data['level'])}\n"
                    f"Суммарный XP: {user_data['total_xp']}"
                ),
                color=discord.Color.green()
            )
            embed.set_footer(text="Shenята | TWITCH")
            await log_channel.send(embed=embed)

    await bot.process_commands(message)
@bot.command(name='модер')
@commands.has_role(REQUIRED_ROLE_NAME)
@commands.has_permissions(manage_roles=True)
async def moder(ctx):
    if not ctx.message.mentions:
        await ctx.send('⚠️ Пожалуйста, укажи пользователя через @упоминание.')
        return
    member = ctx.message.mentions[0]
    role = discord.utils.get(ctx.guild.roles, name=MODERATOR_ROLE_NAME)
    if role is None:
        await ctx.send(f'❌ Роль "{MODERATOR_ROLE_NAME}" не найдена.')
        return

    try:
        await member.add_roles(role, reason=f'Выдана роль модера по команде {ctx.author}')

        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel:
            embed_log = discord.Embed(
                title="✅ Роль модератора выдана",
                description=(
                    f"Модератор: {ctx.author.mention}\n"
                    f"Пользователь: {member.mention}\n"
                    f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')}"
                ),
                color=discord.Color.green()
            )
            embed_log.set_footer(text="by BOSasha • Shenята | TWITCH")
            await log_channel.send(embed=embed_log)

        channel = bot.get_channel(WELCOME_CHANNEL_ID)
        if channel:
            embed_welcome = discord.Embed(
                title="🚀 Новый модератор на борту!",
                description=(
                    f"🎮 Загрузка модератора: {member.mention}...\n"
                    "✅ Рады видеть тебя в Shenята | TWITCH!\n"
                    "🛡️ Вперёд, к новым победам и справедливости!"
                ),
                color=discord.Color.blue()
            )
            embed_welcome.set_image(url=GIF_WELCOME_URL)
            embed_welcome.set_thumbnail(url=member.display_avatar.url)
            embed_welcome.set_footer(text="by BOSasha • Shenята | TWITCH")
            await channel.send(embed=embed_welcome)
        else:
            await ctx.send('❌ Канал для приветствия не найден.')

    except discord.Forbidden:
        await ctx.send('❌ У меня нет прав на изменение ролей или отправку сообщений.')
    except Exception as e:
        await ctx.send(f"⚠️ Ошибка: {e}")



@bot.command(name='снять')
@commands.has_role(REQUIRED_ROLE_NAME)
@commands.has_permissions(manage_roles=True)
async def remove_mod(ctx):
    if not ctx.message.mentions:
        await ctx.send('⚠️ Пожалуйста, укажи пользователя через @упоминание.')
        return
    member = ctx.message.mentions[0]
    role = discord.utils.get(ctx.guild.roles, name=MODERATOR_ROLE_NAME)
    if role is None:
        await ctx.send(f'❌ Роль "{MODERATOR_ROLE_NAME}" не найдена.')
        return

    try:
        await member.remove_roles(role, reason=f'Снятие роли модера по команде {ctx.author}')

        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel:
            embed_log = discord.Embed(
                title="❌ Роль модератора снята",
                description=(
                    f"Модератор: {ctx.author.mention}\n"
                    f"Пользователь: {member.mention}\n"
                    f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')}"
                ),
                color=discord.Color.red()
            )
            embed_log.set_footer(text="by BOSasha • Shenята | TWITCH")
            await log_channel.send(embed=embed_log)

        channel = bot.get_channel(WELCOME_CHANNEL_ID)
        if channel:
            embed_goodbye = discord.Embed(
                title="👋 Модератор покидает пост",
                description=(
                    f"🎮 Снятие роли модератора: {member.mention}...\n"
                    "✅ Спасибо за твою работу в Shenята | TWITCH!\n"
                    "🛡️ Удачи и новых достижений!"
                ),
                color=discord.Color.red()
            )
            embed_goodbye.set_image(url=GIF_GOODBYE_URL)
            embed_goodbye.set_thumbnail(url=member.display_avatar.url)
            embed_goodbye.set_footer(text="by BOSasha • Shenята | TWITCH")
            await channel.send(embed=embed_goodbye)
        else:
            await ctx.send('❌ Канал для прощания не найден.')

    except discord.Forbidden:
        await ctx.send('❌ У меня нет прав на изменение ролей.')
    except Exception as e:
        await ctx.send(f"⚠️ Ошибка: {e}")



@bot.command(name='ранг')
async def rank(ctx, member: discord.Member = None):
    if not discord.utils.get(ctx.author.roles, name='✭') and ctx.channel.id != COMMANDS_CHANNEL_ID:
        await ctx.message.delete()
        msg = await ctx.send(f"⚠️ Используй эту команду только в канале <#{COMMANDS_CHANNEL_ID}>.")
        await msg.delete(delay=3)
        return

    if not member:
        member = ctx.author

    user_data = get_user_data(str(member.id))
    level = user_data.get("level", 0)
    xp = user_data.get("xp", 0)
    next_level_xp = (level * 100) + 200
    xp_needed = max(0, next_level_xp - xp)

    embed = discord.Embed(
        title=f"Карточка игрока: {member.display_name}",
        color=discord.Color.blue()
    )
    embed.set_thumbnail(url=member.display_avatar.url)
    embed.add_field(name="Уровень", value=str(level), inline=True)
    embed.add_field(name="XP", value=f"{xp} / {next_level_xp}", inline=True)
    embed.add_field(name="До следующего уровня", value=f"{xp_needed} XP", inline=False)
    embed.set_footer(
        text="by BOSasha • Shenята | TWITCH",
        icon_url=ctx.guild.icon.url if ctx.guild.icon else discord.Embed.Empty
    )
    await ctx.send(embed=embed)



@bot.command(name='топ')
async def top(ctx):
    if not discord.utils.get(ctx.author.roles, name='✭') and ctx.channel.id != COMMANDS_CHANNEL_ID:
        await ctx.message.delete()
        msg = await ctx.send(f"⚠️ Используй эту команду только в канале <#{COMMANDS_CHANNEL_ID}>.")
        await msg.delete(delay=3)
        return

    top_users = list(users_collection.find().sort([("level", -1), ("xp", -1)]).limit(10))
    if not top_users:
        await ctx.send("Пока никто не набрал XP.")
        return

    embed = discord.Embed(
        title="🔥 Топ 10 по уровню",
        color=discord.Color.blue()
    )
    for i, user_data in enumerate(top_users):
        member = ctx.guild.get_member(int(user_data["_id"]))
        name = member.display_name if member else f"Пользователь {user_data['_id']}"
        level = user_data.get("level", 0)
        xp = user_data.get("xp", 0)
        next_level_xp = (level * 100) + 200
        embed.add_field(
            name=f"{i + 1}. {name}",
            value=f"Уровень: **{level}**\nXP: **{xp}** / {next_level_xp}",
            inline=False
        )
    embed.set_footer(
        text="by BOSasha • Shenята | TWITCH",
        icon_url=ctx.guild.icon.url if ctx.guild.icon else discord.Embed.Empty
    )
    await ctx.send(embed=embed)

@bot.command(name='установить')
@commands.has_role(REQUIRED_ROLE_NAME)
@commands.has_permissions(manage_roles=True)
async def set_level(ctx, member: discord.Member, level: int):
    user_id = str(member.id)
    user_data = get_user_data(user_id)
    old_level = user_data.get("level", 0)

    user_data["level"] = level
    user_data["xp"] = 0 

    total_xp = 0
    for lvl in range(level):
        total_xp += (lvl * 100) + 200
    user_data["total_xp"] = total_xp

    update_user_data(user_id, user_data)

    for lvl, role_name in LEVEL_ROLES.items():
        role = discord.utils.get(ctx.guild.roles, name=role_name)
        if role and role in member.roles:
            await member.remove_roles(role)

    give_role_name = None
    for lvl, role_name in sorted(LEVEL_ROLES.items()):
        if level >= lvl:
            give_role_name = role_name
        else:
            break

    if give_role_name:
        role = discord.utils.get(ctx.guild.roles, name=give_role_name)
        if role and role not in member.roles:
            await member.add_roles(role)

    await ctx.send(f"✅ Уровень пользователя {member.mention} изменён с {old_level} на {level}.")

    log_channel = bot.get_channel(LOG_CHANNEL_ID)
    if log_channel:
        embed = discord.Embed(
            title="⚙️ Уровень установлен вручную",
            description=(
                f"Модератор: {ctx.author.mention}\n"
                f"Пользователь: {member.mention}\n"
                f"Старый уровень: {old_level}\n"
                f"Новый уровень: {level}\n"
                f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')}"
            ),
            color=discord.Color.orange()
        )
        embed.set_footer(
            text="by BOSasha • Shenята | TWITCH",
            icon_url=ctx.guild.icon.url if ctx.guild.icon else discord.Embed.Empty
        )
        await log_channel.send(embed=embed)

import json
import random

@bot.command(name='сказка')
async def fairy_tale(ctx):
    if not discord.utils.get(ctx.author.roles, name='✭') and ctx.channel.id != COMMANDS_CHANNEL_ID:
        await ctx.message.delete()
        msg = await ctx.send(f"⚠️ Используй эту команду только в канале <#{COMMANDS_CHANNEL_ID}>.")
        await msg.delete(delay=3)
        return

    try:
        with open("fairytales.json", "r", encoding="utf-8") as f:
            fairy_tales = json.load(f)
    except Exception as e:
        await ctx.send("❌ Не удалось загрузить сказки.")
        print(f"[ОШИБКА] При чтении fairytales.json: {e}")
        return

    index = random.randint(0, len(fairy_tales) - 1)
    tale = fairy_tales[index]
    title = tale["title"]
    story = tale["story"]

    embed = discord.Embed(
        title=f"📖 {title}",
        description=story,
        color=discord.Color.blue()
    )
    embed.set_footer(
        text=f"Сказка {index + 1} из {len(fairy_tales)} | by BOSasha • Shenята | TWITCH",
        icon_url=ctx.guild.icon.url if ctx.guild.icon else None
    )
    await ctx.send(embed=embed)

@bot.command(name='помощь')
async def help_command(ctx):
    if not discord.utils.get(ctx.author.roles, name='✭') and ctx.channel.id != COMMANDS_CHANNEL_ID:
        await ctx.message.delete()
        msg = await ctx.send(f"⚠️ Используй эту команду только в канале <#{COMMANDS_CHANNEL_ID}>.")
        await msg.delete(delay=3)
        return
    embed = discord.Embed(
        title="🧊 BotFRusH | Команды помощи",
        description="**Вот список доступных команд:**",
        color=discord.Color.blue()
    )
    embed.set_footer(text="by BOSasha • Shenята | TWITCH", icon_url=ctx.guild.icon.url if ctx.guild.icon else None)
    if discord.utils.get(ctx.author.roles, name='✭'):
        embed.add_field(
            name="🔸 Команды куратора:",
            value=(
                "`!модер @юзер` — выдать модера\n"
                "`!снять @юзер` — снять модера\n"
                "`!установить @юзер <уровень>` — установить уровень\n"
                "`!хот <сообщение>` - отправить сообщение в канал hot-info"
            ),
            inline=False
        )
    if discord.utils.get(ctx.author.roles, name='✭') or discord.utils.get(ctx.author.roles, name=MODERATOR_ROLE_NAME):
        embed.add_field(
            name="💥 Команды модератора:",
            value=(
                "`!мьют @юзер <время>` — замутить\n"
                "`!размьют @юзер` — размутить\n"
                "`!бан @юзер <причина>` — бан\n"
                "`!разбан @юзер` — разбан\n"
                "`!кик @юзер <причина>` — кик"
            ),
            inline=False
        )
    embed.add_field(
        name="🔹 Рейтинг:",
        value="`!ранг` — твой уровень и XP\n`!топ` — топ 10 по активности",
        inline=False
    )
    embed.add_field(
        name="🎮 Развлечения:",
        value="`!сказка` — расскажет тебе казку на ночь",
        inline=False
    )
    embed.add_field(
        name="🌐 DDnet команды:",
        value="`!стат <ник>` — получить статистику игрока",
        inline=False
    )
    await ctx.send(embed=embed)
    from aiohttp import web
    import threading
    async def handle(request):
        return web.Response(text="Bot is running")
    app = web.Application()
    app.router.add_get('/', handle)
    def run_web():
        web.run_app(app, port=3000)
    threading.Thread(target=run_web).start()
def has_moderator_role():
    async def predicate(ctx):
        has_star = discord.utils.get(ctx.author.roles, name=REQUIRED_ROLE_NAME)
        has_mod = discord.utils.get(ctx.author.roles, name=MODERATOR_ROLE_NAME)
        if has_star is None and has_mod is None:
            await ctx.send("🚫 У тебя нет прав на выполнение этой команды!")
            return False
        return True
    return commands.check(predicate)
@bot.command(name='мьют')
@has_moderator_role()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member = None, *, args="10m"):
    if member is None:
        await ctx.send("⚠️ Укажи пользователя для мьюта!")
        return
    if member == ctx.author:
        await ctx.send("⚠️ Ты не можешь замутить самого себя!")
        return
    muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not muted_role:
        muted_role = await ctx.guild.create_role(name="Muted", reason="Роль для мьюта")
        for channel in ctx.guild.channels:
            await channel.set_permissions(muted_role, send_messages=False, add_reactions=False)
    import re
    time_dict = {
        "s": 1, "с": 1, "sec": 1, "сек": 1,
        "m": 60, "м": 60, "min": 60, "мин": 60,
        "h": 3600, "ч": 3600, "hour": 3600, "час": 3600,
        "d": 86400, "д": 86400, "day": 86400, "день": 86400
    }
    match = re.match(r'(\d+)([a-zA-Zа-яА-Я]+)', args)
    if not match:
        await ctx.send("⚠️ Неверный формат времени! Используй: 10м, 5h, 2д, 30min и т.д.")
        return
    time_amount = int(match.group(1))
    time_unit = match.group(2).lower()
    if time_unit not in time_dict:
        await ctx.send("⚠️ Неверная единица времени! Используй: с/s, м/m, ч/h, д/d")
        return
    mute_seconds = time_amount * time_dict[time_unit]
    try:
        await member.add_roles(muted_role, reason=f"Мьют от {ctx.author}")
        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel:
            embed = discord.Embed(
                title="🔇 Пользователь замучен",
                description=(
                    f"Модератор: {ctx.author.mention}\n"
                    f"Пользователь: {member.mention}\n"
                    f"Время: {args}\n"
                    f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')}"
                ),
                color=discord.Color.orange()
            )
            embed.set_footer(
                text="by BOSasha • Shenята | TWITCH",
                icon_url=ctx.guild.icon.url if ctx.guild.icon else discord.Embed.Empty
            )
            await log_channel.send(embed=embed)
        await ctx.send(f"🔇 {member.mention} замучен на {args}.")
        await discord.utils.sleep_until(discord.utils.utcnow() + timedelta(seconds=mute_seconds))
        if muted_role in member.roles:
            await member.remove_roles(muted_role, reason="Автоматическое размьючивание")
            if log_channel:
                embed = discord.Embed(
                    title="🔊 Автоматическое размьючивание",
                    description=(
                        f"Пользователь: {member.mention}\n"
                        "Время мьюта истекло\n"
                        f"Дата: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
                    ),
                    color=discord.Color.green()
                )
                embed.set_footer(
                    text="by BOSasha • Shenята | TWITCH",
                    icon_url=ctx.guild.icon.url if ctx.guild.icon else discord.Embed.Empty
                )
                await log_channel.send(embed=embed)
    except discord.Forbidden:
        await ctx.send("❌ У меня нет прав на изменение ролей!")
@bot.command(name='размьют')
@has_moderator_role()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member = None):
    if member is None:
        await ctx.send("⚠️ Укажи пользователя для размьюта!")
        return
    muted_role = discord.utils.get(ctx.guild.roles, name="Muted")
    if not muted_role:
        await ctx.send("❌ Роль 'Muted' не найдена!")
        return
    if muted_role not in member.roles:
        await ctx.send(f"⚠️ {member.mention} не замучен!")
        return
    try:
        await member.remove_roles(muted_role, reason=f"Размьют от {ctx.author}")
        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel:
            embed = discord.Embed(
                title="🔊 Пользователь размучен",
                description=(
                    f"Модератор: {ctx.author.mention}\n"
                    f"Пользователь: {member.mention}\n"
                    f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')}"
                ),
                color=discord.Color.green()
            )
            embed.set_footer(
                text="by BOSasha • Shenята | TWITCH",
                icon_url=ctx.guild.icon.url if ctx.guild.icon else discord.Embed.Empty
            )
            await log_channel.send(embed=embed)
        await ctx.send(f"🔊 {member.mention} размучен")
    except discord.Forbidden:
        await ctx.send("❌ У меня нет прав на изменение ролей!")
@bot.command(name='бан')
@has_moderator_role()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member = None, *, args=""):
    if member is None:
        await ctx.send(embed=discord.Embed(description="⚠️ Укажи пользователя для бана через @упоминание.", color=discord.Color.red()))
        return
    if member == ctx.author:
        await ctx.send(embed=discord.Embed(description="⚠️ Ты не можешь забанить самого себя!", color=discord.Color.red()))
        return

    ban_seconds = None
    reason = "Причина не указана"
    duration_str = "навсегда"

    if args:
        parts = args.split(' ', 1)
        first_part = parts[0]
        time_dict = {
            "s": 1, "с": 1, "sec": 1, "сек": 1,
            "m": 60, "м": 60, "min": 60, "мин": 60,
            "h": 3600, "ч": 3600, "hour": 3600, "час": 3600,
            "d": 86400, "д": 86400, "day": 86400, "день": 86400
        }
        import re
        match = re.match(r'(\d+)([a-zA-Zа-яА-Я]+)', first_part)
        if match:
            time_amount = int(match.group(1))
            time_unit = match.group(2).lower()
            if time_unit in time_dict:
                ban_seconds = time_amount * time_dict[time_unit]
                duration_str = first_part
                if len(parts) > 1:
                    reason = parts[1]
            else:
                reason = args
        else:
            reason = args

    try:
        await member.ban(reason=f"Забанен модератором {ctx.author}: {reason}")

        # Embed для чата
        embed_chat = discord.Embed(
            title="🔨 Пользователь забанен",
            color=discord.Color.red()
        )
        embed_chat.add_field(name="Пользователь", value=member.mention, inline=True)
        embed_chat.add_field(name="Модератор", value=ctx.author.mention, inline=True)
        embed_chat.add_field(name="Время", value=f"{duration_str}", inline=True)
        embed_chat.add_field(name="Причина", value=reason, inline=False)
        embed_chat.set_footer(text=f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')} • by BOSasha • Shenята | TWITCH")

        await ctx.send(embed=embed_chat)

        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel:
            embed_log = discord.Embed(
                title="🔨 Пользователь забанен",
                color=discord.Color.red()
            )
            embed_log.add_field(name="Пользователь", value=f"{member} ({member.id})", inline=True)
            embed_log.add_field(name="Модератор", value=f"{ctx.author} ({ctx.author.id})", inline=True)
            embed_log.add_field(name="Время", value=f"{duration_str}", inline=True)
            embed_log.add_field(name="Причина", value=reason, inline=False)
            embed_log.set_footer(text=f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')} • by BOSasha • Shenята | TWITCH")
            await log_channel.send(embed=embed_log)

        if ban_seconds:
            await discord.utils.sleep_until(discord.utils.utcnow() + timedelta(seconds=ban_seconds))
            try:
                await ctx.guild.unban(member, reason="Автоматический разбан")
                if log_channel:
                    embed_unban_log = discord.Embed(
                        title="✅ Автоматический разбан",
                        description=f"Пользователь {member} был автоматически разбанен после истечения срока бана.",
                        color=discord.Color.green()
                    )
                    embed_unban_log.set_footer(text=f"Дата: {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')} • by BOSasha • Shenята | TWITCH")
                    await log_channel.send(embed=embed_unban_log)
            except discord.NotFound:
                pass

    except discord.Forbidden:
        await ctx.send(embed=discord.Embed(description="❌ У меня нет прав на бан пользователей!", color=discord.Color.red()))
@bot.command(name='разбан')
@has_moderator_role()
@commands.has_permissions(ban_members=True)
async def unban(ctx, *, member_name: str = None):
    if member_name is None:
        await ctx.send(embed=discord.Embed(description="⚠️ Укажи пользователя для разбана в формате Имя#Тэг или Имя.", color=discord.Color.red()))
        return
    banned_users = [entry async for entry in ctx.guild.bans()]
    for ban_entry in banned_users:
        user = ban_entry.user
        if f"{user.name}#{user.discriminator}" == member_name or user.name == member_name:
            try:
                await ctx.guild.unban(user, reason=f"Разбанен модератором {ctx.author}")

                embed_chat = discord.Embed(
                    title="✅ Пользователь разбанен",
                    color=discord.Color.green()
                )
                embed_chat.add_field(name="Пользователь", value=f"{user.name}#{user.discriminator}", inline=True)
                embed_chat.add_field(name="Модератор", value=ctx.author.mention, inline=True)
                embed_chat.set_footer(text=f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')} • by BOSasha • Shenята | TWITCH")

                await ctx.send(embed=embed_chat)

                log_channel = bot.get_channel(LOG_CHANNEL_ID)
                if log_channel:
                    embed_log = discord.Embed(
                        title="✅ Пользователь разбанен",
                        color=discord.Color.green()
                    )
                    embed_log.add_field(name="Пользователь", value=f"{user.name}#{user.discriminator} ({user.id})", inline=True)
                    embed_log.add_field(name="Модератор", value=f"{ctx.author} ({ctx.author.id})", inline=True)
                    embed_log.set_footer(text=f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')} • by BOSasha • Shenята | TWITCH")
                    await log_channel.send(embed=embed_log)

                return
            except discord.Forbidden:
                await ctx.send(embed=discord.Embed(description="❌ У меня нет прав на разбан пользователей!", color=discord.Color.red()))
                return
    await ctx.send(embed=discord.Embed(description="❌ Пользователь с таким именем не найден в списке забаненных!", color=discord.Color.red()))
@bot.command(name='кик')
@has_moderator_role()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member = None, *, reason="Причина не указана"):
    if member is None:
        await ctx.send(embed=discord.Embed(description="⚠️ Укажи пользователя для кика через @упоминание.", color=discord.Color.red()))
        return
    if member == ctx.author:
        await ctx.send(embed=discord.Embed(description="⚠️ Ты не можешь кикнуть самого себя!", color=discord.Color.red()))
        return
    try:
        await member.kick(reason=f"Кикнут модератором {ctx.author}: {reason}")

        embed_chat = discord.Embed(
            title="👢 Пользователь кикнут",
            color=discord.Color.orange()
        )
        embed_chat.add_field(name="Пользователь", value=member.mention, inline=True)
        embed_chat.add_field(name="Модератор", value=ctx.author.mention, inline=True)
        embed_chat.add_field(name="Причина", value=reason, inline=False)
        embed_chat.set_footer(text=f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')} • by BOSasha • Shenята | TWITCH")

        await ctx.send(embed=embed_chat)

        log_channel = bot.get_channel(LOG_CHANNEL_ID)
        if log_channel:
            embed_log = discord.Embed(
                title="👢 Пользователь кикнут",
                color=discord.Color.orange()
            )
            embed_log.add_field(name="Пользователь", value=f"{member} ({member.id})", inline=True)
            embed_log.add_field(name="Модератор", value=f"{ctx.author} ({ctx.author.id})", inline=True)
            embed_log.add_field(name="Причина", value=reason, inline=False)
            embed_log.set_footer(text=f"Дата: {ctx.message.created_at.strftime('%Y-%m-%d %H:%M:%S')} • by BOSasha • Shenята | TWITCH")
            await log_channel.send(embed=embed_log)

    except discord.Forbidden:
        await ctx.send(embed=discord.Embed(description="❌ У меня нет прав на кик пользователей!", color=discord.Color.red()))
@bot.command(name='стат')
async def stat(ctx, player_name: str):
    has_star = discord.utils.get(ctx.author.roles, name=REQUIRED_ROLE_NAME)
    if not has_star and ctx.channel.id != COMMANDS_CHANNEL_ID:
        await ctx.message.delete()
        msg = await ctx.send(f"⚠️ Используй эту команду только в канале <#{COMMANDS_CHANNEL_ID}>.")
        await msg.delete(delay=3)
        return
    player_name_encoded = urllib.parse.quote(player_name)
    url = f"https://ddnet.org/players/?json2={player_name_encoded}"
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Referer': 'https://ddnet.org/players/',
        'Accept': 'application/json',
    }
    async with aiohttp.ClientSession() as session:
        async with session.get(url, headers=headers) as resp:
            if resp.status != 200:
                await ctx.send(f"❌ Не удалось получить данные для {player_name}.")
                return
            data = await resp.json(content_type=None)
            if not data:
                await ctx.send(f"❌ Нет данных для {player_name}.")
                return

            points = data.get('points', {})
            rank = data.get('rank', {})
            team_rank = data.get('team_rank', {})
            points_last_year = data.get('points_last_year', {})
            first_finish = data.get('first_finish', {})
            favorite_server = data.get('favorite_server', {}).get('server', '—')
            favorite_partners = data.get('favorite_partners', [])
            hours_year = data.get('hours_played_past_365_days', 0)

            if favorite_partners:
                partner_name = favorite_partners[0].get('name', '—')
                partner_finishes = favorite_partners[0].get('finishes', 0)
                flag = "🇷🇺" if favorite_server == "RUS" else "🌐"
                favorite_partner = f"{flag} {partner_name} — {partner_finishes} финишей"
            else:
                favorite_partner = "—"

            if first_finish:
                ts = first_finish.get('timestamp')
                first_map = first_finish.get('map', '—')
                if ts:
                    first_date = datetime.utcfromtimestamp(ts).strftime('%Y-%m-%d')
                else:
                    first_date = "—"
            else:
                first_map = "—"
                first_date = "—"

            flag_player = "🇷🇺" if favorite_server == "RUS" else "🌐"

            embed = discord.Embed(
                title=f"{flag_player} **{player_name}**",
                color=discord.Color.blue()
            )

            embed.add_field(
                name="👥 Любимый партнёр:",
                value=favorite_partner,
                inline=False
            )

            embed.add_field(
                name="🏆 Поинты:",
                value=f"{points.get('points', '—')} — #{points.get('rank', '—')}",
                inline=False
            )

            embed.add_field(
                name="🎯 Rank:",
                value=f"{rank.get('points', '—')} — #{rank.get('rank', '—')}",
                inline=False
            )

            embed.add_field(
                name="👑 Team rank:",
                value=f"{team_rank.get('points', '—')} — #{team_rank.get('rank', '—')}",
                inline=False
            )

            embed.add_field(
                name="🕒 Часы за год:",
                value=f"{round(hours_year, 1)} ч" if hours_year else "—",
                inline=False
            )

            embed.add_field(
                name="🚀 Первый финиш:",
                value=f"{first_map} ({first_date})",
                inline=False
            )
            embed.set_footer(text="by BOSasha • Shenята | TWITCH", icon_url=ctx.guild.icon.url if ctx.guild and ctx.guild.icon else None)
            await ctx.send(embed=embed)
HOT_CHANNEL_ID = 1277679142128713780
@bot.command(name='хот')
@commands.has_role(REQUIRED_ROLE_NAME)  
async def hot(ctx, *, message_text=None):
    hot_channel = ctx.guild.get_channel(HOT_CHANNEL_ID)
    if hot_channel is None:
        await ctx.send("❗ Канал для горячих сообщений не найден.")
        return

    if message_text is None and len(ctx.message.attachments) == 0:
        await ctx.send("❗ Напиши сообщение и/или прикрепи фото.")
        return

    embed = discord.Embed(
        description=message_text or "",
        color=discord.Color.blue()
    )

    if ctx.message.attachments:
        attachment = ctx.message.attachments[0]
        if attachment.content_type and attachment.content_type.startswith("image"):
            embed.set_image(url=attachment.url)

    embed.set_footer(
        text="by BOSasha • Shenята | TWITCH",
        icon_url=ctx.guild.icon.url if ctx.guild.icon else None
    )

    await hot_channel.send(embed=embed)
@bot.event
async def on_command_error(ctx, error):
    if isinstance(error, commands.CheckFailure):
        return
    if isinstance(error, commands.CommandNotFound):
        return
    await ctx.send(f"⚠️ Ошибка: {error}")
  
async def run():
    await bot.start(TOKEN)

if __name__ == "__main__":
    asyncio.run(run())