import os
import aiohttp
from twitchio.ext import commands
import twitchio

TWITCH_TOKEN = os.getenv('TWITCH_OAUTH_TOKEN')
TWITCH_CLIENT_ID = os.getenv('TWITCH_CLIENT_ID')
TWITCH_CLIENT_SECRET = os.getenv('TWITCH_CLIENT_SECRET')
TWITCH_BOT_ID = int(os.getenv('TWITCH_BOT_ID'))
TWITCH_CHANNELS = ['shenfrush']
TWITCH_PREFIX = '!'

def get_twitch_version():
    return getattr(twitchio, '__version__', 'unknown')

class TwitchBot(commands.Bot):
    def __init__(self):
        super().__init__(
            token=TWITCH_TOKEN,
            client_id=TWITCH_CLIENT_ID,
            client_secret=TWITCH_CLIENT_SECRET,
            bot_id=TWITCH_BOT_ID,
            prefix=TWITCH_PREFIX,
            initial_channels=TWITCH_CHANNELS,
        )

    async def event_ready(self):
        print(f"✅ Twitch бот запущен как {self.user.name}")

    async def event_message(self, message):
        if message.echo:
            return 
        print(f"[{message.channel.name}] {message.author.name}: {message.content}")
        await self.handle_commands(message)
        print("Handled commands for message")

    @commands.command(name='дс')
    async def discord(self, ctx):
        await ctx.send("🎮 Заходи в наш Discord: https://discord.gg/z8uNTmdN5P")

    @commands.command(name='бот')
    async def info(self, ctx):
        await ctx.send("🤖 Я бот от BOSasha!")

    @commands.command(name='ping')
    async def ping(self, ctx):
        await ctx.send("pong")

def create_bot():
    print(f"🧩 TwitchIO версия: {get_twitch_version()}")
    return TwitchBot()

