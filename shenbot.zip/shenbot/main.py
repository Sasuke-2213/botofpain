import asyncio
import threading
import os
from flask import Flask

import twitch_bot
import discord_bot

DISCORD_TOKEN = os.getenv('DISCORD_TOKEN')

app = Flask(__name__)

@app.route('/')
def home():
    return "✅ Бот работает!"

@app.route('/ping')
def ping():
    return "pong", 200

def run_web():
    print("[WEB] Запуск веб-сервера...")
    app.run(host='0.0.0.0', port=8080)

async def main():
    twitch = twitch_bot.create_bot()
    twitch_task = asyncio.create_task(twitch.start())

    discord_task = asyncio.create_task(discord_bot.bot.start(DISCORD_TOKEN))
    await asyncio.gather(twitch_task, discord_task)

if __name__ == "__main__":
    web_thread = threading.Thread(target=run_web, daemon=True)
    web_thread.start()
    asyncio.run(main())
